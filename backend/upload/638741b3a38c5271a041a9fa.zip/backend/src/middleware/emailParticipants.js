const emailParticipants = async(req, res, next) => {
    next()
}

module.exports = emailParticipants;